
import { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { generateOTP, sendWhatsAppOTP, verifyOTP } from "@/utils/otpUtils";

export const useOtpVerification = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { register } = useAuth();
  const [otp, setOtp] = useState<string>("");
  const [isVerifying, setIsVerifying] = useState<boolean>(false);
  const [isSending, setIsSending] = useState<boolean>(false);
  const [countdown, setCountdown] = useState<number>(60);
  const [error, setError] = useState<string | null>(null);

  // Extract user registration data from state
  const userData = location.state?.userData;
  
  // Initialize OTP sending and redirect if no user data
  useEffect(() => {
    if (!userData) {
      navigate("/login", { replace: true });
    } else {
      // Generate and send OTP when component mounts
      sendOtp();
    }
  }, [userData, navigate]);

  // Countdown timer for OTP resend
  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [countdown]);

  // Send OTP via WhatsApp
  const sendOtp = async () => {
    if (!userData?.phoneNumber) {
      setError("No phone number provided");
      return;
    }
    
    setIsSending(true);
    setError(null);
    
    const newOtp = generateOTP();
    console.log("Generated OTP:", newOtp); // For development debugging
    
    try {
      const sent = await sendWhatsAppOTP(userData.phoneNumber, newOtp);
      
      setIsSending(false);
      
      if (sent) {
        toast.success(`OTP sent to ${userData.phoneNumber}`);
        setCountdown(60);
      } else {
        setError("Failed to send OTP. Please try again.");
        toast.error("Failed to send OTP. Please try again.");
      }
    } catch (error) {
      console.error("Error in sendOtp:", error);
      setIsSending(false);
      setError("Failed to send OTP. Please try again.");
      toast.error("Failed to send OTP. Please try again.");
    }
  };

  // Resend OTP
  const handleResendOtp = () => {
    if (countdown === 0 && !isSending) {
      sendOtp();
    }
  };

  // Verify OTP and complete registration
  const handleVerifyOtp = () => {
    setIsVerifying(true);
    setError(null);

    if (!userData?.phoneNumber) {
      setError("No phone number provided");
      setIsVerifying(false);
      return;
    }

    // Verify OTP matches
    if (verifyOTP(userData.phoneNumber, otp)) {
      // Complete registration
      register(userData.username, userData.password, userData.phoneNumber);
      toast.success("Phone number verified successfully!");
      navigate("/");
    } else {
      setError("Invalid or expired OTP. Please try again.");
      setIsVerifying(false);
    }
  };

  // Go back to registration
  const handleGoBack = () => {
    navigate("/login", { state: { tab: "register", userData } });
  };

  return {
    userData,
    otp,
    setOtp,
    isVerifying,
    isSending,
    countdown,
    error,
    handleResendOtp,
    handleVerifyOtp,
    handleGoBack,
    setError
  };
};
