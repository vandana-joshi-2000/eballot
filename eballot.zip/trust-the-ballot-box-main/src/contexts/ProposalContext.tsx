
import React, { createContext, useState, useEffect, useContext } from "react";
import { getVotesForProposal } from "@/lib/blockchain";

export interface Choice {
  id: string;
  text: string;
}

export interface Proposal {
  id: string;
  title: string;
  description: string;
  choices: Choice[];
  creator: string;
  createdAt: number; // timestamp
  endTime: number; // timestamp for vote end time
}

interface ProposalContextType {
  proposals: Proposal[];
  addProposal: (proposal: Omit<Proposal, "id" | "createdAt">) => void;
  getProposalById: (id: string) => Proposal | undefined;
  getProposalResults: (id: string) => { [choice: string]: number };
}

const ProposalContext = createContext<ProposalContextType | undefined>(undefined);

export const ProposalProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [proposals, setProposals] = useState<Proposal[]>([]);

  // Load proposals from localStorage on mount
  useEffect(() => {
    const storedProposals = localStorage.getItem("proposals");
    if (storedProposals) {
      try {
        setProposals(JSON.parse(storedProposals));
      } catch (e) {
        console.error("Failed to parse stored proposals:", e);
      }
    }
  }, []);

  // Save proposals to localStorage on change
  useEffect(() => {
    localStorage.setItem("proposals", JSON.stringify(proposals));
  }, [proposals]);

  const addProposal = (proposal: Omit<Proposal, "id" | "createdAt">) => {
    const newProposal: Proposal = {
      ...proposal,
      id: `proposal_${Date.now()}`,
      createdAt: Date.now(),
    };
    
    setProposals([...proposals, newProposal]);
  };

  const getProposalById = (id: string) => {
    return proposals.find(p => p.id === id);
  };

  const getProposalResults = (id: string) => {
    return getVotesForProposal(id);
  };

  return (
    <ProposalContext.Provider value={{
      proposals,
      addProposal,
      getProposalById,
      getProposalResults,
    }}>
      {children}
    </ProposalContext.Provider>
  );
};

export const useProposals = () => {
  const context = useContext(ProposalContext);
  if (context === undefined) {
    throw new Error("useProposals must be used within a ProposalProvider");
  }
  return context;
};
