import React, { createContext, useState, useEffect, useContext } from "react";
import { toast } from "sonner";

interface User {
  id: string;
  username: string;
  isAdmin: boolean;
  phoneNumber?: string;
}

interface AuthContextType {
  user: User | null;
  login: (username: string, password: string) => void;
  adminLogin: () => void;
  register: (username: string, password: string, phoneNumber?: string) => void;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);

  // Check for existing session on mount
  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    if (storedUser) {
      try {
        setUser(JSON.parse(storedUser));
      } catch (e) {
        console.error("Failed to parse stored user:", e);
        localStorage.removeItem("user");
      }
    }
  }, []);

  const login = (username: string, password: string) => {
    // In a real app, this would validate against a backend
    // For our demo, we'll do a simple check
    const users = JSON.parse(localStorage.getItem("users") || "[]");
    const foundUser = users.find((u: any) => 
      u.username === username && u.password === password
    );
    
    if (foundUser) {
      const authenticatedUser = {
        id: foundUser.id,
        username: foundUser.username,
        isAdmin: foundUser.isAdmin || false,
        phoneNumber: foundUser.phoneNumber
      };
      
      setUser(authenticatedUser);
      localStorage.setItem("user", JSON.stringify(authenticatedUser));
      toast.success(`Welcome back, ${username}!`);
    } else {
      toast.error("Invalid username or password");
    }
  };
  
  const adminLogin = () => {
    // Check if admin user exists
    const users = JSON.parse(localStorage.getItem("users") || "[]");
    let adminUser = users.find((u: any) => u.username === "admin");
    
    // Create admin user if it doesn't exist
    if (!adminUser) {
      adminUser = {
        id: `user_admin_${Date.now()}`,
        username: "admin",
        password: "admin",
        isAdmin: true
      };
      users.push(adminUser);
      localStorage.setItem("users", JSON.stringify(users));
    }
    
    // Set up admin session
    const authenticatedAdmin = {
      id: adminUser.id,
      username: adminUser.username,
      isAdmin: true
    };
    
    setUser(authenticatedAdmin);
    localStorage.setItem("user", JSON.stringify(authenticatedAdmin));
    toast.success("Logged in as Admin");
  };
  
  const register = (username: string, password: string, phoneNumber?: string) => {
    // In a real app, this would create a user in a database
    // For our demo, we'll use localStorage
    if (!username || !password) {
      toast.error("Username and password are required");
      return;
    }
    
    const users = JSON.parse(localStorage.getItem("users") || "[]");
    
    // Check if username already exists
    if (users.some((u: any) => u.username === username)) {
      toast.error("Username already taken");
      return;
    }
    
    // Create new user - regular users have no admin privileges
    const newUser = {
      id: `user_${Date.now()}`,
      username,
      password,
      phoneNumber,
      isAdmin: false, // Changed from "users.length === 0" to always false
      verifiedPhone: true // Phone is verified since we've completed OTP verification
    };
    
    users.push(newUser);
    localStorage.setItem("users", JSON.stringify(users));
    
    // Auto login after registration
    const authenticatedUser = {
      id: newUser.id,
      username: newUser.username,
      isAdmin: newUser.isAdmin,
      phoneNumber: newUser.phoneNumber
    };
    
    setUser(authenticatedUser);
    localStorage.setItem("user", JSON.stringify(authenticatedUser));
    
    toast.success("Registration successful!");
  };
  
  const logout = () => {
    setUser(null);
    localStorage.removeItem("user");
    toast.info("You've been logged out");
  };

  return (
    <AuthContext.Provider value={{
      user,
      login,
      adminLogin,
      register,
      logout,
      isAuthenticated: !!user,
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};
