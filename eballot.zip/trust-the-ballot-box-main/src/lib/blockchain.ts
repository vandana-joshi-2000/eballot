
import { toast } from "sonner";

// Types
export interface Block {
  index: number;
  timestamp: number;
  data: VoteData;
  previousHash: string;
  hash: string;
  nonce: number;
}

export interface VoteData {
  voter: string;
  proposal: string;
  choice: string;
}

export interface Blockchain {
  chain: Block[];
  difficulty: number;
  pendingTransactions: VoteData[];
  miningReward: number;
}

// Create a simple blockchain implementation
const createBlockchain = (): Blockchain => {
  const blockchain: Blockchain = {
    chain: [],
    difficulty: 2,
    pendingTransactions: [],
    miningReward: 1,
  };

  // Create genesis block
  const genesisBlock = createBlock(0, "0", { voter: "genesis", proposal: "genesis", choice: "genesis" });
  blockchain.chain.push(genesisBlock);
  
  return blockchain;
};

// Singleton blockchain instance
let blockchainInstance: Blockchain | null = null;

// Get the blockchain instance
export const getBlockchain = (): Blockchain => {
  if (!blockchainInstance) {
    blockchainInstance = createBlockchain();
    
    // Load from localStorage if available
    const savedChain = localStorage.getItem("blockchain");
    if (savedChain) {
      try {
        const parsed = JSON.parse(savedChain);
        if (parsed && Array.isArray(parsed.chain)) {
          blockchainInstance.chain = parsed.chain;
          console.log("Loaded blockchain from storage:", blockchainInstance.chain.length, "blocks");
        }
      } catch (error) {
        console.error("Failed to parse blockchain from localStorage", error);
      }
    }
  }
  return blockchainInstance;
};

// Save blockchain to localStorage
const saveBlockchain = (blockchain: Blockchain): void => {
  localStorage.setItem("blockchain", JSON.stringify(blockchain));
};

// Calculate hash for a block
export const calculateHash = (
  index: number,
  previousHash: string,
  timestamp: number,
  data: VoteData,
  nonce: number
): string => {
  // In a real app, we would use a proper hashing algorithm
  // For this demo, we'll create a simple string and hash it using browser API
  const text = index + previousHash + timestamp + JSON.stringify(data) + nonce;
  
  // Using a simplified hash function for demonstration
  let hash = 0;
  for (let i = 0; i < text.length; i++) {
    const char = text.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32bit integer
  }
  return hash.toString(16).padStart(8, '0');
};

// Create a new block
export const createBlock = (index: number, previousHash: string, data: VoteData): Block => {
  const timestamp = Date.now();
  let nonce = 0;
  let hash = calculateHash(index, previousHash, timestamp, data, nonce);
  
  // Simple proof of work
  while (hash.substring(0, 2) !== "00") {
    nonce++;
    hash = calculateHash(index, previousHash, timestamp, data, nonce);
  }

  return {
    index,
    timestamp,
    data,
    previousHash,
    hash,
    nonce,
  };
};

// Add a new vote to the blockchain
export const addVote = (voter: string, proposal: string, choice: string): Promise<Block> => {
  return new Promise((resolve) => {
    const blockchain = getBlockchain();
    const voteData: VoteData = { voter, proposal, choice };
    
    // Create a new block
    const previousBlock = blockchain.chain[blockchain.chain.length - 1];
    const newBlock = createBlock(previousBlock.index + 1, previousBlock.hash, voteData);
    
    // Add the block to the chain
    blockchain.chain.push(newBlock);
    
    // Save blockchain
    saveBlockchain(blockchain);
    
    console.log(`Vote added to block ${newBlock.index}`);
    
    // In a real implementation, we would broadcast this to the network
    // For this demo, we'll just return the new block
    resolve(newBlock);
  });
};

// Verify the blockchain integrity
export const verifyBlockchain = (): boolean => {
  const blockchain = getBlockchain();
  
  for (let i = 1; i < blockchain.chain.length; i++) {
    const currentBlock = blockchain.chain[i];
    const previousBlock = blockchain.chain[i - 1];
    
    // Check if hash is valid
    const hash = calculateHash(
      currentBlock.index,
      currentBlock.previousHash,
      currentBlock.timestamp,
      currentBlock.data,
      currentBlock.nonce
    );
    
    if (currentBlock.hash !== hash) {
      console.error("Block hash invalid:", currentBlock);
      return false;
    }
    
    // Check if this block points to the correct previous block
    if (currentBlock.previousHash !== previousBlock.hash) {
      console.error("Previous hash doesn't match:", currentBlock);
      return false;
    }
  }
  
  return true;
};

// Get votes for a specific proposal
export const getVotesForProposal = (proposalId: string): { [choice: string]: number } => {
  const blockchain = getBlockchain();
  const votes: { [choice: string]: number } = {};
  
  blockchain.chain.forEach((block) => {
    if (block.data.proposal === proposalId) {
      const choice = block.data.choice;
      votes[choice] = (votes[choice] || 0) + 1;
    }
  });
  
  return votes;
};

// Check if a voter has already voted on a proposal
export const hasVoted = (voter: string, proposalId: string): boolean => {
  if (!voter || !proposalId) return false;
  
  const blockchain = getBlockchain();
  
  // Explicitly check that the voter ID exactly matches the voter ID stored in the block
  // and that the proposal ID exactly matches the proposal ID we're checking
  return blockchain.chain.some((block) => 
    block.data.voter === voter && 
    block.data.proposal === proposalId
  );
};

// Submit a vote and add it to the blockchain
export const submitVote = async (voter: string, proposalId: string, choice: string) => {
  // First check if this specific voter has already voted on this specific proposal
  if (hasVoted(voter, proposalId)) {
    toast.error("You have already voted on this proposal");
    return false;
  }
  
  try {
    const block = await addVote(voter, proposalId, choice);
    toast.success("Vote successfully recorded on the blockchain");
    return true;
  } catch (error) {
    console.error("Error adding vote to blockchain:", error);
    toast.error("Failed to record vote");
    return false;
  }
};
