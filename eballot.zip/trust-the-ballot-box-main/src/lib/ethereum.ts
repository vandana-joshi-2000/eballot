
import { ethers } from "ethers";
import { toast } from "sonner";

// The ABI (Application Binary Interface) for a simple voting smart contract
// In a production app, this would be generated from the actual smart contract
const VOTING_CONTRACT_ABI = [
  // Basic voting functions
  "function vote(string proposalId, string choice) public",
  "function hasVoted(address voter, string proposalId) public view returns (bool)",
  "function getVotes(string proposalId) public view returns (string[] memory choices, uint256[] memory counts)",
  "event VoteCast(address indexed voter, string proposalId, string choice, uint256 timestamp)"
];

// Smart contract address - in production, this would be your deployed contract
const CONTRACT_ADDRESS = "0x0000000000000000000000000000000000000000";

export interface EthereumVoteData {
  voter: string; // Ethereum address
  proposal: string;
  choice: string;
  timestamp: number;
  transactionHash: string;
}

// Initialize provider and contract
let provider: ethers.providers.Web3Provider | null = null;
let signer: ethers.Signer | null = null;
let votingContract: ethers.Contract | null = null;

// Check if MetaMask is installed
export const isMetaMaskInstalled = () => {
  return window.ethereum !== undefined;
};

// Disconnect wallet - reset our application state
export const disconnectWallet = (): void => {
  provider = null;
  signer = null;
  votingContract = null;
  console.log("Wallet connection reset in application");
};

// Setup listener for logout events
if (typeof window !== 'undefined') {
  window.addEventListener('userLoggedOut', () => {
    disconnectWallet();
  });
}

// Connect to Ethereum via MetaMask
export const connectWallet = async (): Promise<string | null> => {
  if (!isMetaMaskInstalled()) {
    toast.error("MetaMask is not installed. Please install MetaMask to use this feature.");
    return null;
  }

  try {
    // Request account access
    const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
    
    // Initialize ethers provider
    provider = new ethers.providers.Web3Provider(window.ethereum);
    signer = provider.getSigner();
    
    // Initialize contract
    votingContract = new ethers.Contract(CONTRACT_ADDRESS, VOTING_CONTRACT_ABI, signer);
    
    return accounts[0];
  } catch (error) {
    console.error("Error connecting to MetaMask:", error);
    toast.error("Failed to connect to MetaMask. Please try again.");
    return null;
  }
};

// Check if user has already voted on a proposal
export const hasVotedOnChain = async (address: string, proposalId: string): Promise<boolean> => {
  if (!address || !proposalId) return false;
  
  if (!votingContract || !provider) {
    await connectWallet();
    if (!votingContract) return false;
  }
  
  try {
    // Try to check on the blockchain first
    return await votingContract.hasVoted(address, proposalId);
  } catch (error) {
    console.error("Error checking vote status:", error);
    // Fall back to localStorage but ensure we're checking the specific user and proposal
    return hasVotedFallback(address, proposalId);
  }
};

// Submit a vote to the Ethereum blockchain
export const submitVoteOnChain = async (
  address: string, 
  proposalId: string, 
  choice: string
): Promise<boolean> => {
  if (!address || !proposalId) return false;
  
  if (!votingContract || !signer) {
    const connected = await connectWallet();
    if (!connected || !votingContract) {
      toast.error("Please connect your wallet to vote");
      return false;
    }
  }

  try {
    // Check if already voted - pass both the user address and proposal ID
    const alreadyVoted = await hasVotedOnChain(address, proposalId);
    if (alreadyVoted) {
      toast.error("You have already voted on this proposal");
      return false;
    }

    // Submit transaction to vote
    const tx = await votingContract.vote(proposalId, choice);
    
    // Wait for transaction to be mined
    toast.loading("Processing vote on the blockchain...");
    await tx.wait();
    
    toast.success("Vote successfully recorded on the Ethereum blockchain!");
    return true;
  } catch (error: any) {
    console.error("Error submitting vote to blockchain:", error);
    
    // Handle user rejected transaction
    if (error.code === 4001) { // MetaMask user rejected
      toast.error("Transaction was rejected");
    } else {
      toast.error("Failed to record vote on blockchain. Using fallback storage.");
      // Fall back to localStorage if blockchain transaction fails
      return submitVoteFallback(address, proposalId, choice);
    }
    return false;
  }
};

// Get votes for a proposal from the blockchain
export const getVotesFromChain = async (proposalId: string): Promise<{ [choice: string]: number }> => {
  if (!votingContract || !provider) {
    await connectWallet();
    if (!votingContract) return {};
  }
  
  try {
    const [choices, counts] = await votingContract.getVotes(proposalId);
    
    // Convert to the expected format
    const results: { [choice: string]: number } = {};
    for (let i = 0; i < choices.length; i++) {
      results[choices[i]] = counts[i].toNumber();
    }
    
    return results;
  } catch (error) {
    console.error("Error getting votes from blockchain:", error);
    // Fall back to localStorage
    return getVotesFallback(proposalId);
  }
};

// ----- Fallback functions that use localStorage when blockchain operations fail -----

// Import original blockchain functions for fallback
import { 
  hasVoted as hasVotedFallback,
  submitVote as submitVoteFallback,
  getVotesForProposal as getVotesFallback
} from "./blockchain";

// Export the blockchain functions with Ethereum as primary and localStorage as fallback
export const hasVoted = hasVotedOnChain;
export const submitVote = submitVoteOnChain;
export const getVotesForProposal = getVotesFromChain;

// Declare ethereum property on window object
declare global {
  interface Window {
    ethereum?: any;
  }
}
