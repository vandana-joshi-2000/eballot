
// OTP Generation and SMS/Email Utilities

// Generate a random 6-digit OTP
export const generateOTP = (): string => {
  const otp = Math.floor(100000 + Math.random() * 900000).toString();
  console.log(`%c[OTP GENERATED] ${otp}`, 'background: #4CAF50; color: white; padding: 2px 4px; border-radius: 2px;');
  return otp;
};

// MessageFury API Key
const MESSAGE_FURY_API_KEY = "71AAD5B587C974ACCD91817B8D283092.EVAF7AS2OPCJ39MTG9BWZDND6I7MBYSCB97OACL0CMG4DQGS184RNUZIIW1L7ISUWRY86G4E15G9Y9Y6YSUXY7MC7DXTARA22RDWFXQLDH6413EN10XO76UJNF27I59BJVLYT520PMI20HFVF2BRMVBF56G4LMQY1P9MG5T304E0J604DA0M22I69U71CXZXQR69UG7XBZLP92INPBPIY7DHJUV4RX5RYZ3DZTL81VBCBFDZCOC4YKLMPSM708ZF";

// Store OTP in localStorage (development purposes)
export const storeOTP = (phoneNumber: string, otp: string): void => {
  localStorage.setItem(`otp_${phoneNumber}`, JSON.stringify({
    code: otp,
    expires: Date.now() + 10 * 60 * 1000, // 10 minutes expiry
    attempts: 0
  }));
  
  console.log(`%c[OTP STORED] Phone: ${phoneNumber}, Code: ${otp}`, 'background: #2196F3; color: white; padding: 2px 4px; border-radius: 2px;');
};

// Send OTP via MessageFury API (with fallback to localStorage)
export const sendWhatsAppOTP = async (phoneNumber: string, otp: string): Promise<boolean> => {
  console.log(`%c[OTP REQUEST] Sending to: ${phoneNumber}, Code: ${otp}`, 'background: #FF9800; color: white; padding: 2px 4px; border-radius: 2px;');
  
  // Always store OTP in localStorage for development/fallback
  storeOTP(phoneNumber, otp);
  
  try {
    // Prepare proper international format for the phone number
    // Remove + sign and any spaces as MessageFury might have specific format requirements
    const formattedPhoneNumber = phoneNumber.replace(/\+|\s+/g, '');
    
    console.log(`[MessageFury API] Using formatted phone number: ${formattedPhoneNumber}`);
    
    // MessageFury API endpoint - using the standard messaging endpoint
    const endpoint = "https://api.messagefury.com/v2/messages";
    
    // Prepare the message payload for MessageFury - updated to match MessageFury's expected format
    const messagePayload = {
      recipients: [formattedPhoneNumber],
      content: `Your TrustBallotChain verification code is: ${otp}. Valid for 10 minutes.`,
      sender: "TrustBallot", // This should be your registered sender ID in MessageFury
      messageType: "OTP",
      webhookUrl: "" // Leave empty if not using webhooks yet
    };
    
    console.log("[MessageFury API] Request payload:", JSON.stringify(messagePayload, null, 2));
    
    // Make the API request to MessageFury
    const response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${MESSAGE_FURY_API_KEY}`
      },
      body: JSON.stringify(messagePayload)
    });
    
    // Log the full response
    const responseText = await response.text();
    let data;
    
    try {
      data = JSON.parse(responseText);
      console.log("%c[MessageFury API Response]", 'background: #673AB7; color: white; padding: 2px 4px; border-radius: 2px;', data);
    } catch (err) {
      console.error("%c[MessageFury API Response Parse Error]", 'background: #F44336; color: white; padding: 2px 4px; border-radius: 2px;', responseText);
      data = { error: "Failed to parse response" };
    }
    
    // Check if MessageFury API call was successful
    if (response.ok) {
      console.log(`%c[OTP SENT SUCCESSFULLY] MessageID: ${data.messageId || 'N/A'}`, 'background: #4CAF50; color: white; padding: 2px 4px; border-radius: 2px;');
      return true;
    }
    
    // If there was an issue with the MessageFury API call
    console.error("%c[MessageFury API Error]", 'background: #F44336; color: white; padding: 2px 4px; border-radius: 2px;', data);
    console.log(`%c[FALLBACK ACTIVATED] Using localStorage OTP instead of MessageFury delivery`, 'background: #FF9800; color: white; padding: 2px 4px; border-radius: 2px;');
    
    // Since we stored the OTP in localStorage, we'll return true for development
    console.log(`%c[DEVELOPMENT MODE] OTP: ${otp} for phone: ${phoneNumber}`, 'background: #9C27B0; color: white; padding: 2px 4px; border-radius: 2px;');
    return true;
  } catch (error) {
    console.error("%c[OTP SEND ERROR]", 'background: #F44336; color: white; padding: 2px 4px; border-radius: 2px;', error);
    // Since we stored the OTP in localStorage, we'll return true for development
    console.log(`%c[DEVELOPMENT FALLBACK] Using localStorage OTP: ${otp}`, 'background: #FF9800; color: white; padding: 2px 4px; border-radius: 2px;');
    return true;
  }
};

// Verify OTP from localStorage
export const verifyOTP = (phoneNumber: string, userEnteredOTP: string): boolean => {
  try {
    console.log(`%c[OTP VERIFICATION] Checking OTP for ${phoneNumber}: ${userEnteredOTP}`, 'background: #607D8B; color: white; padding: 2px 4px; border-radius: 2px;');
    const storedOTPData = localStorage.getItem(`otp_${phoneNumber}`);
    
    if (!storedOTPData) {
      console.error(`%c[OTP VERIFICATION FAILED] No OTP found for phone: ${phoneNumber}`, 'background: #F44336; color: white; padding: 2px 4px; border-radius: 2px;');
      return false;
    }
    
    const { code, expires, attempts } = JSON.parse(storedOTPData);
    console.log(`%c[OTP VERIFICATION] Stored OTP: ${code}, Entered OTP: ${userEnteredOTP}`, 'background: #607D8B; color: white; padding: 2px 4px; border-radius: 2px;');
    
    // Update attempts
    const updatedAttempts = attempts + 1;
    localStorage.setItem(`otp_${phoneNumber}`, JSON.stringify({
      code,
      expires,
      attempts: updatedAttempts
    }));
    
    // Check if OTP is expired
    if (Date.now() > expires) {
      console.error(`%c[OTP EXPIRED] OTP for ${phoneNumber} has expired`, 'background: #F44336; color: white; padding: 2px 4px; border-radius: 2px;');
      return false;
    }
    
    // Check for too many attempts (3 max)
    if (updatedAttempts > 3) {
      console.error(`%c[TOO MANY ATTEMPTS] ${updatedAttempts} attempts for phone: ${phoneNumber}`, 'background: #F44336; color: white; padding: 2px 4px; border-radius: 2px;');
      return false;
    }
    
    // Verify OTP
    if (code === userEnteredOTP) {
      // Clear the OTP after successful verification
      localStorage.removeItem(`otp_${phoneNumber}`);
      console.log(`%c[OTP VERIFIED SUCCESSFULLY] for phone: ${phoneNumber}`, 'background: #4CAF50; color: white; padding: 2px 4px; border-radius: 2px;');
      return true;
    }
    
    console.error(`%c[INVALID OTP] Expected: ${code}, Got: ${userEnteredOTP}`, 'background: #F44336; color: white; padding: 2px 4px; border-radius: 2px;');
    return false;
  } catch (error) {
    console.error(`%c[OTP VERIFICATION ERROR]`, 'background: #F44336; color: white; padding: 2px 4px; border-radius: 2px;', error);
    return false;
  }
};

// Validate phone number format
export const validatePhoneNumber = (phoneNumber: string): boolean => {
  // International phone number format with country code
  // Allows formats like +1234567890, +12 3456 7890, etc.
  const phoneRegex = /^\+[1-9]\d{1,14}$/;
  const isValid = phoneRegex.test(phoneNumber.replace(/\s+/g, ''));
  
  console.log(`%c[PHONE VALIDATION] ${phoneNumber}: ${isValid ? 'Valid' : 'Invalid'}`, 'background: #009688; color: white; padding: 2px 4px; border-radius: 2px;');
  return isValid;
};
