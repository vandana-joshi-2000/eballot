import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import { Shield, Vote, Download, Menu, X } from "lucide-react";
import { toast } from "sonner";
import { useIsMobile } from "@/hooks/use-mobile";
import QRCodeDisplay from "./QRCodeDisplay";
import AdminLoginDialog from "./AdminLoginDialog";

const Navbar: React.FC = () => {
  const { user, logout, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const isMobile = useIsMobile();
  const [menuOpen, setMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  const handleExportApp = () => {
    // Create a JSON representation of the localStorage data
    const appData = {
      users: JSON.parse(localStorage.getItem("users") || "[]"),
      proposals: JSON.parse(localStorage.getItem("proposals") || "[]"),
      votes: JSON.parse(localStorage.getItem("votes") || "[]"),
    };
    
    // Filter out sensitive information (like passwords)
    const sanitizedData = {
      ...appData,
      users: appData.users.map((user: any) => ({ 
        id: user.id, 
        username: user.username,
        isAdmin: user.isAdmin 
      })),
    };
    
    // Convert the data to a JSON string
    const jsonData = JSON.stringify(sanitizedData, null, 2);
    
    // Create a Blob containing the data
    const blob = new Blob([jsonData], { type: "application/json" });
    
    // Create a download link and trigger the download
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "trustballot-export.json";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    toast.success("Application data exported successfully!");
  };

  const toggleMenu = () => setMenuOpen(!menuOpen);

  return (
    <nav className="bg-blockchain-blue text-white shadow-md px-4 py-3 relative">
      <div className="container mx-auto flex justify-between items-center">
        <Link to="/" className="flex items-center gap-2 text-xl font-bold z-20">
          <Vote className="text-blockchain-accent h-6 w-6" />
          <span>eBallot</span>
        </Link>
        
        {isMobile ? (
          <>
            <div className="flex items-center gap-2 z-20">
              <QRCodeDisplay />
              <Button 
                variant="ghost" 
                className="text-white p-1"
                onClick={toggleMenu}
              >
                {menuOpen ? <X size={24} /> : <Menu size={24} />}
              </Button>
            </div>
            
            {menuOpen && (
              <div className="fixed inset-0 bg-blockchain-blue z-10 pt-16 px-6 flex flex-col items-center">
                <div className="flex flex-col items-center gap-6 w-full">
                  <Link 
                    to="/" 
                    className="text-xl hover:text-blockchain-purple transition-colors py-2 w-full text-center border-b border-blockchain-purple/30"
                    onClick={() => setMenuOpen(false)}
                  >
                    Home
                  </Link>
                  
                  {isAuthenticated ? (
                    <>
                      {user?.isAdmin && (
                        <>
                          <Link 
                            to="/create" 
                            className="text-xl hover:text-blockchain-purple transition-colors py-2 w-full text-center border-b border-blockchain-purple/30"
                            onClick={() => setMenuOpen(false)}
                          >
                            Create Proposal
                          </Link>
                          <Link 
                            to="/admin" 
                            className="text-xl hover:text-blockchain-purple transition-colors py-2 w-full text-center border-b border-blockchain-purple/30 flex justify-center items-center gap-1"
                            onClick={() => setMenuOpen(false)}
                          >
                            <span>Admin</span>
                            <Shield className="h-4 w-4 text-blockchain-purple" />
                          </Link>
                        </>
                      )}
                      
                      <div className="flex flex-col items-center gap-2 py-4">
                        <div className="flex items-center gap-2">
                          {user?.isAdmin && <Shield className="h-4 w-4 text-blockchain-purple" />}
                          <span className="text-lg">{user?.username}</span>
                        </div>
                        <Button 
                          variant="outline" 
                          className="border-blockchain-purple text-white hover:bg-blockchain-purple/20"
                          onClick={() => {
                            handleLogout();
                            setMenuOpen(false);
                          }}
                        >
                          Logout
                        </Button>
                      </div>
                    </>
                  ) : (
                    <>
                      <Button 
                        variant="outline"
                        className="border-blockchain-purple text-white bg-blockchain-purple/20 hover:bg-blockchain-purple/40 my-4 w-full"
                        onClick={() => {
                          navigate("/login");
                          setMenuOpen(false);
                        }}
                      >
                        Login / Register
                      </Button>
                      
                      <AdminLoginDialog>
                        <Button 
                          variant="outline"
                          className="border-blockchain-purple text-white bg-blockchain-purple/20 hover:bg-blockchain-purple/40 mb-4 w-full"
                          onClick={() => setMenuOpen(false)}
                        >
                          Admin Login
                        </Button>
                      </AdminLoginDialog>
                    </>
                  )}
                  
                  <Button 
                    variant="outline" 
                    className="bg-transparent border-blockchain-purple text-white hover:bg-blockchain-purple/20 transition-colors flex items-center gap-2"
                    onClick={() => {
                      handleExportApp();
                      setMenuOpen(false);
                    }}
                  >
                    <Download className="h-4 w-4" />
                    Export Data
                  </Button>
                </div>
              </div>
            )}
          </>
        ) : (
          <div className="flex items-center gap-4">
            <Link to="/" className="hover:text-blockchain-purple transition-colors">
              Home
            </Link>
            
            {isAuthenticated ? (
              <>
                {user?.isAdmin && (
                  <>
                    <Link to="/create" className="hover:text-blockchain-purple transition-colors flex items-center gap-1">
                      <span>Create Proposal</span>
                    </Link>
                    <Link to="/admin" className="hover:text-blockchain-purple transition-colors flex items-center gap-1">
                      <span>Admin</span>
                      <Shield className="h-4 w-4 text-blockchain-purple" />
                    </Link>
                  </>
                )}
                
                <div className="flex items-center gap-2 ml-4">
                  <div className="flex items-center gap-2">
                    {user?.isAdmin ? (
                      <Shield className="h-4 w-4 text-blockchain-purple" />
                    ) : null}
                    <span>{user?.username}</span>
                  </div>
                  <Button 
                    variant="ghost" 
                    className="hover:text-blockchain-purple transition-colors"
                    onClick={handleLogout}
                  >
                    Logout
                  </Button>
                </div>
              </>
            ) : (
              <div className="flex items-center gap-2">
                <Button 
                  variant="ghost"
                  className="hover:text-blockchain-purple transition-colors bg-blockchain-purple/20 text-white"
                  onClick={() => navigate("/login")}
                >
                  Login / Register
                </Button>
                
                <AdminLoginDialog>
                  <Button 
                    variant="outline"
                    className="border-blockchain-purple text-white bg-blockchain-purple/20 hover:bg-blockchain-purple/40"
                  >
                    Admin Login
                  </Button>
                </AdminLoginDialog>
              </div>
            )}
            
            <div className="flex items-center gap-2">
              <QRCodeDisplay />
              <Button 
                variant="outline" 
                className="bg-transparent border-blockchain-purple text-white hover:bg-blockchain-purple/20 transition-colors flex items-center gap-2"
                onClick={handleExportApp}
              >
                <Download className="h-4 w-4" />
                Export Data
              </Button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
