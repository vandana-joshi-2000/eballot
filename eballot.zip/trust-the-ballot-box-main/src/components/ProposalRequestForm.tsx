
import React, { useState } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { PencilIcon, Trash2 } from "lucide-react";

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";

// Define form schema
const requestFormSchema = z.object({
  title: z.string().min(5, {
    message: "Title must be at least 5 characters.",
  }).max(100, {
    message: "Title must not exceed 100 characters.",
  }),
  description: z.string().min(20, {
    message: "Description must be at least 20 characters.",
  }).max(500, {
    message: "Description must not exceed 500 characters.",
  }),
});

type RequestFormValues = z.infer<typeof requestFormSchema>;

interface Choice {
  id: string;
  text: string;
}

// Interface for proposal requests
interface ProposalRequest {
  id: string;
  title: string;
  description: string;
  choices: Choice[];
  requester: string;
  requesterId: string;
  status: "pending" | "approved" | "rejected";
  createdAt: number;
  endTime?: number;
}

const ProposalRequestForm: React.FC = () => {
  const { user } = useAuth();
  const [choices, setChoices] = useState<Choice[]>([
    { id: `choice_${Date.now()}_1`, text: "" },
    { id: `choice_${Date.now()}_2`, text: "" },
  ]);
  const [endDate, setEndDate] = useState("");

  const form = useForm<RequestFormValues>({
    resolver: zodResolver(requestFormSchema),
    defaultValues: {
      title: "",
      description: "",
    },
  });

  const addChoice = () => {
    setChoices([...choices, { id: `choice_${Date.now()}`, text: "" }]);
  };

  const removeChoice = (id: string) => {
    if (choices.length <= 2) {
      toast.error("A proposal must have at least 2 choices");
      return;
    }
    setChoices(choices.filter(choice => choice.id !== id));
  };

  const updateChoice = (id: string, text: string) => {
    setChoices(choices.map(choice => 
      choice.id === id ? { ...choice, text } : choice
    ));
  };

  const onSubmit = (data: RequestFormValues) => {
    if (!user) {
      toast.error("You must be logged in to submit a proposal request.");
      return;
    }

    // Validate that all choices have text
    const emptyChoices = choices.some(choice => !choice.text.trim());
    if (emptyChoices) {
      toast.error("Please provide text for all choices");
      return;
    }
    
    // Validate end date is in the future
    let endTimestamp;
    if (endDate) {
      endTimestamp = new Date(endDate).getTime();
      if (endTimestamp <= Date.now()) {
        toast.error("End date must be in the future");
        return;
      }
    }

    // Create new proposal request
    const newRequest: ProposalRequest = {
      id: `request_${Date.now()}`,
      title: data.title,
      description: data.description,
      choices: choices,
      requester: user.username,
      requesterId: user.id,
      status: "pending",
      createdAt: Date.now(),
      endTime: endTimestamp,
    };

    // Get existing requests or initialize empty array
    const existingRequests: ProposalRequest[] = JSON.parse(
      localStorage.getItem("proposalRequests") || "[]"
    );

    // Add new request and save to localStorage
    localStorage.setItem(
      "proposalRequests",
      JSON.stringify([...existingRequests, newRequest])
    );

    // Show success message
    toast.success("Proposal request submitted successfully!");
    
    // Reset form
    form.reset();
    setChoices([
      { id: `choice_${Date.now()}_1`, text: "" },
      { id: `choice_${Date.now()}_2`, text: "" },
    ]);
    setEndDate("");
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-5 mb-8 border border-gray-200 dark:border-gray-700">
      <div className="flex items-center gap-2 mb-4">
        <PencilIcon className="h-5 w-5 text-blockchain-purple" />
        <h2 className="text-xl font-semibold">Submit Proposal Request</h2>
      </div>
      
      <p className="text-gray-600 dark:text-gray-300 mb-4">
        Only administrators can create proposals directly. Submit your proposal idea here, and an administrator will review it.
      </p>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <FormField
            control={form.control}
            name="title"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Proposal Title</FormLabel>
                <FormControl>
                  <Input placeholder="Enter proposal title" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Proposal Description</FormLabel>
                <FormControl>
                  <Textarea 
                    placeholder="Describe your proposal in detail..." 
                    className="min-h-[120px]" 
                    {...field} 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="space-y-2">
            <FormLabel>Choices</FormLabel>
            <p className="text-sm text-gray-500 mb-2">Add options for voters to choose from</p>
            
            {choices.map((choice, index) => (
              <div key={choice.id} className="flex gap-2 items-center">
                <Input 
                  value={choice.text}
                  onChange={(e) => updateChoice(choice.id, e.target.value)}
                  placeholder={`Choice ${index + 1}`}
                />
                <Button 
                  type="button" 
                  variant="ghost" 
                  size="icon" 
                  className="shrink-0"
                  onClick={() => removeChoice(choice.id)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            ))}
            
            <Button 
              type="button" 
              variant="outline" 
              onClick={addChoice}
              className="mt-2"
            >
              Add Choice
            </Button>
          </div>

          <div className="space-y-2">
            <FormLabel htmlFor="end-date">End Date (Optional)</FormLabel>
            <Input 
              id="end-date"
              type="datetime-local"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
            />
            <p className="text-xs text-gray-500">When voting on this proposal should end</p>
          </div>

          <Button type="submit" className="bg-blockchain-blue hover:bg-blockchain-blue/90">
            Submit Request
          </Button>
        </form>
      </Form>
    </div>
  );
};

export default ProposalRequestForm;
