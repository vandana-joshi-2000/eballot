
import React, { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate } from "react-router-dom";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Shield } from "lucide-react";
import { toast } from "sonner";

interface AdminLoginDialogProps {
  children: React.ReactNode;
}

const AdminLoginDialog: React.FC<AdminLoginDialogProps> = ({ children }) => {
  const { adminLogin } = useAuth();
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  
  const handleAdminLogin = () => {
    setIsLoading(true);
    
    // Check credentials
    if (username === "admin" && password === "admin") {
      adminLogin();
      navigate("/admin");
      toast.success("Logged in as Admin");
    } else {
      toast.error("Invalid admin credentials");
    }
    
    setIsLoading(false);
  };
  
  return (
    <Dialog>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-blockchain-purple" />
            Admin Login
          </DialogTitle>
          <DialogDescription>
            Please enter your admin credentials to continue
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid gap-2">
            <label htmlFor="username" className="text-sm font-medium">
              Username
            </label>
            <input
              id="username"
              type="text"
              className="px-3 py-2 border rounded-md"
              placeholder="Enter admin username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
          </div>
          
          <div className="grid gap-2">
            <label htmlFor="password" className="text-sm font-medium">
              Password
            </label>
            <input
              id="password"
              type="password"
              className="px-3 py-2 border rounded-md"
              placeholder="Enter admin password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
        </div>
        <div className="flex justify-between">
          <DialogClose asChild>
            <Button variant="outline">Cancel</Button>
          </DialogClose>
          <Button 
            className="bg-blockchain-purple hover:bg-blockchain-purple/90" 
            onClick={handleAdminLogin}
            disabled={isLoading}
          >
            <Shield className="h-4 w-4 mr-2" />
            Login as Admin
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default AdminLoginDialog;
