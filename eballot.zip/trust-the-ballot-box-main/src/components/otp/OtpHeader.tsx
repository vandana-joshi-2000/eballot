
import React from "react";
import { Vote } from "lucide-react";
import { CardTitle, CardDescription } from "@/components/ui/card";

interface OtpHeaderProps {
  phoneNumber?: string;
  showLogo?: boolean;
}

const OtpHeader: React.FC<OtpHeaderProps> = ({ phoneNumber, showLogo = false }) => {
  return (
    <>
      {showLogo && (
        <div className="flex justify-center items-center gap-2 mb-4">
          <Vote className="h-8 w-8 text-blockchain-purple" />
          <h1 className="text-2xl font-bold">
            <span className="text-blockchain-blue">TrustBallot</span>
            <span className="text-blockchain-purple">Chain</span>
          </h1>
        </div>
      )}
      
      <CardTitle className="text-xl">OTP Verification</CardTitle>
      <CardDescription>
        We've sent a verification code to {phoneNumber}
        {process.env.NODE_ENV === 'development' && (
          <span className="text-xs block text-muted-foreground mt-1">
            (Check console for the OTP in development mode)
          </span>
        )}
      </CardDescription>
    </>
  );
};

export default OtpHeader;
