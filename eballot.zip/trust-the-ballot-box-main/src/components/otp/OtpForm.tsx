
import React, { useState } from "react";
import { 
  InputOTP, 
  InputOTPGroup, 
  InputOTPSlot 
} from "@/components/ui/input-otp";
import { Button } from "@/components/ui/button";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import { AlertTriangle } from "lucide-react";

interface OtpFormProps {
  otp: string;
  setOtp: (otp: string) => void;
  error: string | null;
  isVerifying: boolean;
  isSending: boolean;
  countdown: number;
  handleResendOtp: () => void;
  handleVerifyOtp: () => void;
  handleGoBack: () => void;
}

const OtpForm: React.FC<OtpFormProps> = ({ 
  otp, 
  setOtp, 
  error, 
  isVerifying, 
  isSending, 
  countdown,
  handleResendOtp,
  handleVerifyOtp,
  handleGoBack
}) => {
  return (
    <>
      {error && (
        <Alert variant="destructive" className="mb-4">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
      
      <div className="flex flex-col items-center space-y-4">
        <InputOTP
          maxLength={6}
          value={otp}
          onChange={(value) => setOtp(value)}
          render={({ slots }) => (
            <InputOTPGroup>
              <InputOTPSlot index={0} className="bg-white text-black border-2 border-gray-300" />
              <InputOTPSlot index={1} className="bg-white text-black border-2 border-gray-300" />
              <InputOTPSlot index={2} className="bg-white text-black border-2 border-gray-300" />
              <InputOTPSlot index={3} className="bg-white text-black border-2 border-gray-300" />
              <InputOTPSlot index={4} className="bg-white text-black border-2 border-gray-300" />
              <InputOTPSlot index={5} className="bg-white text-black border-2 border-gray-300" />
            </InputOTPGroup>
          )}
        />
        
        <div className="text-sm text-gray-500">
          {isSending ? (
            <p>Sending code...</p>
          ) : countdown > 0 ? (
            <p>Resend code in {countdown} seconds</p>
          ) : (
            <Button 
              variant="link" 
              onClick={handleResendOtp}
              className="p-0 h-auto text-blockchain-purple"
            >
              Resend verification code
            </Button>
          )}
        </div>
      </div>

      <div className="flex flex-col space-y-2 mt-6">
        <Button
          className="w-full bg-blockchain-purple hover:bg-blockchain-purple/90"
          onClick={handleVerifyOtp}
          disabled={otp.length !== 6 || isVerifying || isSending}
        >
          {isVerifying ? "Verifying..." : "Verify & Complete Registration"}
        </Button>
        
        <Button
          variant="outline"
          className="w-full"
          onClick={handleGoBack}
          disabled={isVerifying || isSending}
        >
          Back to Registration
        </Button>
      </div>
    </>
  );
};

export default OtpForm;
