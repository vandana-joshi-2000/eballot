
import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { ethers } from "ethers";
import { Button } from "./ui/button";
import { ExternalLink } from "lucide-react";

interface EthereumVisualizerProps {
  proposalId?: string;
  maxTransactions?: number;
}

interface EthereumTransaction {
  hash: string;
  from: string;
  timestamp: number;
  proposalId?: string;
  choice?: string;
  blockNumber: number;
}

const EthereumVisualizer: React.FC<EthereumVisualizerProps> = ({ 
  proposalId,
  maxTransactions = 5 
}) => {
  const [transactions, setTransactions] = useState<EthereumTransaction[]>([]);
  const [isConnected, setIsConnected] = useState(false);
  const [network, setNetwork] = useState<string>("");
  
  useEffect(() => {
    // Check if we're connected to Ethereum
    const checkConnection = async () => {
      if (window.ethereum) {
        try {
          const provider = new ethers.providers.Web3Provider(window.ethereum);
          const network = await provider.getNetwork();
          setNetwork(network.name !== 'unknown' ? network.name : `Chain ID: ${network.chainId}`);
          
          const accounts = await provider.listAccounts();
          setIsConnected(accounts.length > 0);
          
          if (accounts.length > 0) {
            // For a real app, you would fetch actual transactions here
            // This is sample data for demonstration
            fetchSampleTransactions(proposalId);
          }
        } catch (error) {
          console.error("Error connecting to Ethereum:", error);
          setIsConnected(false);
        }
      } else {
        setIsConnected(false);
      }
    };
    
    checkConnection();
  }, [proposalId]);
  
  // This is a mock function - in a real app, you would fetch real transactions from the blockchain
  const fetchSampleTransactions = (filterProposalId?: string) => {
    // Sample data to mimic blockchain transactions
    const sampleTransactions: EthereumTransaction[] = [
      {
        hash: "0x3a4b5c6d7e8f90a1b2c3d4e5f67890a1b2c3d4e5f67890a1b2c3d4e5f67890ab",
        from: "0xd8dA6BF26964aF9D7eEd9e03E53415D37aA96045",
        timestamp: Date.now() - 3600000,
        proposalId: "proposal_1682506938475",
        choice: "choice1",
        blockNumber: 18345678
      },
      {
        hash: "0x1a2b3c4d5e6f70a8b9c0d1e2f3a4b5c6d7e8f90a1b2c3d4e5f67890a1b2c3d4e",
        from: "0x71C7656EC7ab88b098defB751B7401B5f6d8976F",
        timestamp: Date.now() - 7200000,
        proposalId: "proposal_1682506938475",
        choice: "choice2",
        blockNumber: 18345670
      },
      {
        hash: "0x2a3b4c5d6e7f80a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f67890a1b2c3d4e5",
        from: "0x7cB57B5A97eAbe94205C07890BE4c1aD31E486A8",
        timestamp: Date.now() - 10800000,
        proposalId: "proposal_1682412345678",
        choice: "choice1",
        blockNumber: 18345665
      }
    ];
    
    // Filter by proposalId if provided
    const filtered = filterProposalId 
      ? sampleTransactions.filter(tx => tx.proposalId === filterProposalId)
      : sampleTransactions;
    
    // Get the most recent transactions, limited by maxTransactions
    const recent = filtered.sort((a, b) => b.timestamp - a.timestamp).slice(0, maxTransactions);
    setTransactions(recent);
  };
  
  const getExplorerUrl = (hash: string) => {
    // In a real app, determine the explorer based on the current network
    return `https://etherscan.io/tx/${hash}`;
  };
  
  // Display connection status if not connected
  if (!isConnected) {
    return (
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-gray-800 flex items-center gap-2">
          <span>Ethereum Blockchain</span>
        </h3>
        <Card className="border border-blockchain-blue/10">
          <CardContent className="py-6 text-center">
            <p>Connect your Ethereum wallet to view transaction data.</p>
            <Button 
              className="mt-4 bg-blockchain-purple hover:bg-blockchain-purple/90"
              onClick={() => window.ethereum?.request({ method: 'eth_requestAccounts' })}
            >
              Connect Wallet
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  // Display placeholder if no transactions
  if (transactions.length === 0) {
    return (
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-gray-800 flex items-center gap-2">
          <span>Ethereum Blockchain</span>
          <Badge variant="outline" className="bg-blockchain-light text-blockchain-purple">
            {network}
          </Badge>
        </h3>
        <Card className="border border-blockchain-blue/10">
          <CardContent className="py-6 text-center">
            <p>No vote transactions found for this proposal on the blockchain.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-gray-800 flex items-center gap-2">
        <span>Ethereum Blockchain</span>
        <Badge variant="outline" className="bg-blockchain-light text-blockchain-purple">
          {network}
        </Badge>
      </h3>
      
      <div className="flex overflow-x-auto pb-4 space-x-4">
        {transactions.map((tx) => (
          <Card 
            key={tx.hash} 
            className="min-w-[280px] border border-blockchain-blue/10"
          >
            <CardHeader className="bg-gray-50 py-2">
              <div className="flex justify-between items-center">
                <CardTitle className="text-sm">Block #{tx.blockNumber}</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="py-3 text-xs">
              <div className="space-y-1">
                <p><span className="font-semibold">From:</span> {tx.from.slice(0, 6)}...{tx.from.slice(-4)}</p>
                {tx.choice && <p><span className="font-semibold">Choice:</span> {tx.choice}</p>}
                <p><span className="font-semibold">Time:</span> {new Date(tx.timestamp).toLocaleString()}</p>
                <p className="pt-2 font-mono text-xs truncate">
                  <span className="font-semibold">Hash:</span> {tx.hash.slice(0, 10)}...{tx.hash.slice(-8)}
                </p>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="mt-2 text-xs w-full"
                  onClick={() => window.open(getExplorerUrl(tx.hash), '_blank')}
                >
                  View on Etherscan
                  <ExternalLink className="ml-1 h-3 w-3" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default EthereumVisualizer;
