
import React, { useState, useEffect } from "react";
import { getBlockchain, Block } from "@/lib/blockchain";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface BlockchainVisualizerProps {
  maxBlocks?: number;
  proposal?: string;
}

const BlockchainVisualizer: React.FC<BlockchainVisualizerProps> = ({ 
  maxBlocks = 5,
  proposal
}) => {
  const [blocks, setBlocks] = useState<Block[]>([]);
  
  useEffect(() => {
    const blockchain = getBlockchain();
    
    // Filter blocks if proposal is specified, otherwise get latest blocks
    let blocksToShow = [...blockchain.chain];
    
    if (proposal) {
      blocksToShow = blocksToShow.filter(block => 
        block.data.proposal === proposal && block.data.voter !== "genesis"
      );
    }
    
    // Get the latest blocks
    blocksToShow = blocksToShow.slice(-maxBlocks);
    
    setBlocks(blocksToShow);
  }, [maxBlocks, proposal]);
  
  if (blocks.length === 0) {
    return null;
  }

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-gray-800 flex items-center gap-2">
        <span>Blockchain Ledger</span>
        <Badge variant="outline" className="bg-blockchain-light text-blockchain-purple">
          {blocks.length} blocks
        </Badge>
      </h3>
      
      <div className="flex overflow-x-auto pb-4 space-x-4">
        {blocks.map((block, index) => (
          <Card 
            key={block.hash} 
            className={cn(
              "min-w-[280px] border border-blockchain-blue/10",
              block.data.voter === "genesis" && "opacity-50"
            )}
          >
            <CardHeader className="bg-gray-50 py-2">
              <div className="flex justify-between items-center">
                <CardTitle className="text-sm">Block #{block.index}</CardTitle>
                <Badge variant="outline" className="text-xs">
                  Nonce: {block.nonce}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="py-3 text-xs">
              <div className="space-y-1">
                {block.data.voter !== "genesis" ? (
                  <>
                    <p><span className="font-semibold">Voter:</span> {block.data.voter}</p>
                    <p><span className="font-semibold">Choice:</span> {block.data.choice}</p>
                    <p><span className="font-semibold">Time:</span> {new Date(block.timestamp).toLocaleString()}</p>
                  </>
                ) : (
                  <p>Genesis Block</p>
                )}
                <p className="pt-2 font-mono text-xs truncate">
                  <span className="font-semibold">Hash:</span> {block.hash}
                </p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default BlockchainVisualizer;
