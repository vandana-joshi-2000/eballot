
import React, { useState, useEffect } from "react";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { formatDistanceToNow } from "date-fns";
import { useProposals } from "@/contexts/ProposalContext";
import { Badge } from "@/components/ui/badge";

interface Choice {
  id: string;
  text: string;
}

interface ProposalRequest {
  id: string;
  title: string;
  description: string;
  choices: Choice[];
  requester: string;
  requesterId: string;
  status: "pending" | "approved" | "rejected";
  createdAt: number;
  endTime?: number;
}

const ProposalRequests: React.FC = () => {
  const [requests, setRequests] = useState<ProposalRequest[]>([]);
  const { addProposal } = useProposals();

  // Load proposal requests from localStorage
  useEffect(() => {
    const storedRequests = localStorage.getItem("proposalRequests");
    if (storedRequests) {
      try {
        setRequests(JSON.parse(storedRequests));
      } catch (e) {
        console.error("Failed to parse stored proposal requests:", e);
      }
    }
  }, []);

  // Update localStorage when requests change
  useEffect(() => {
    localStorage.setItem("proposalRequests", JSON.stringify(requests));
  }, [requests]);

  const handleApprove = (request: ProposalRequest) => {
    // Convert the request to a proposal
    addProposal({
      title: request.title,
      description: request.description,
      choices: request.choices,
      creator: `${request.requester} (via admin approval)`,
      endTime: request.endTime || Date.now() + 7 * 24 * 60 * 60 * 1000, // Default to 7 days if no end time
    });

    // Update request status
    setRequests(prevRequests =>
      prevRequests.map(req =>
        req.id === request.id ? { ...req, status: "approved" } : req
      )
    );
    toast.success("Proposal request approved and added to active proposals!");
  };

  const handleReject = (id: string) => {
    // Update request status
    setRequests(prevRequests =>
      prevRequests.map(req =>
        req.id === id ? { ...req, status: "rejected" } : req
      )
    );
    toast.success("Proposal request rejected.");
  };

  const pendingRequests = requests.filter(req => req.status === "pending");
  const processedRequests = requests.filter(req => req.status !== "pending");

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Proposal Requests</h2>
      
      {pendingRequests.length === 0 && processedRequests.length === 0 ? (
        <p className="text-gray-500">No proposal requests have been submitted yet.</p>
      ) : (
        <>
          {pendingRequests.length > 0 ? (
            <div className="space-y-4">
              <h3 className="text-xl font-semibold">Pending Requests</h3>
              {pendingRequests.map(request => (
                <Card key={request.id}>
                  <CardHeader>
                    <CardTitle>{request.title}</CardTitle>
                    <CardDescription>
                      Requested by {request.requester} • {formatDistanceToNow(request.createdAt, { addSuffix: true })}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-gray-700 dark:text-gray-300">{request.description}</p>
                    
                    {request.choices && request.choices.length > 0 && (
                      <div className="space-y-2">
                        <h4 className="font-medium text-sm">Proposed Choices:</h4>
                        <div className="flex flex-wrap gap-2">
                          {request.choices.map((choice, index) => (
                            <Badge key={choice.id} variant="outline" className="bg-gray-100 dark:bg-gray-700">
                              {index + 1}. {choice.text}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {request.endTime && (
                      <p className="text-sm text-gray-500">
                        Proposed end date: {new Date(request.endTime).toLocaleString()}
                      </p>
                    )}
                  </CardContent>
                  <CardFooter className="flex justify-end space-x-2">
                    <Button 
                      variant="outline" 
                      onClick={() => handleReject(request.id)}
                    >
                      Reject
                    </Button>
                    <Button onClick={() => handleApprove(request)}>
                      Approve
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          ) : null}

          {processedRequests.length > 0 ? (
            <div className="space-y-4">
              <h3 className="text-xl font-semibold">Processed Requests</h3>
              {processedRequests.map(request => (
                <Card key={request.id} className={request.status === "approved" ? "border-green-500" : "border-red-300"}>
                  <CardHeader>
                    <div className="flex justify-between">
                      <CardTitle>{request.title}</CardTitle>
                      <span className={`px-2 py-1 text-xs rounded-full ${
                        request.status === "approved" ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                      }`}>
                        {request.status.charAt(0).toUpperCase() + request.status.slice(1)}
                      </span>
                    </div>
                    <CardDescription>
                      Requested by {request.requester} • {formatDistanceToNow(request.createdAt, { addSuffix: true })}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <p className="text-gray-700 dark:text-gray-300">{request.description}</p>
                    
                    {request.choices && request.choices.length > 0 && (
                      <div className="space-y-2">
                        <h4 className="font-medium text-sm">Choices:</h4>
                        <div className="flex flex-wrap gap-2">
                          {request.choices.map((choice, index) => (
                            <Badge key={choice.id} variant="outline" className="bg-gray-100 dark:bg-gray-700">
                              {index + 1}. {choice.text}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : null}
        </>
      )}
    </div>
  );
};

export default ProposalRequests;
