
import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { QrCode } from "lucide-react";
import { QRCodeSVG } from "qrcode.react";

interface QRCodeDisplayProps {
  url?: string;
}

const QRCodeDisplay: React.FC<QRCodeDisplayProps> = ({ url }) => {
  const [currentUrl, setCurrentUrl] = useState<string>("");
  
  useEffect(() => {
    // Use provided URL or current window location
    setCurrentUrl(url || window.location.href);
  }, [url]);
  
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button 
          variant="outline" 
          size="sm"
          className="flex items-center gap-2 bg-white text-blockchain-blue hover:bg-gray-100"
        >
          <QrCode className="h-4 w-4" />
          <span className="hidden sm:inline">Share QR</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Share via QR Code</DialogTitle>
          <DialogDescription>Scan this code to access this page</DialogDescription>
        </DialogHeader>
        <div className="flex flex-col items-center justify-center py-4">
          <div className="border rounded-lg p-4 bg-white">
            <QRCodeSVG 
              value={currentUrl} 
              size={200}
              includeMargin={true}
              level="H"
            />
          </div>
          <p className="mt-4 text-sm text-center text-gray-500">
            Scan this QR code to visit:<br />
            <span className="font-mono text-xs break-all">{currentUrl}</span>
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default QRCodeDisplay;
