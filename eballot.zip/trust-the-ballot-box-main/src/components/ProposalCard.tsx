
import React from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { Proposal } from "@/contexts/ProposalContext";

interface ProposalCardProps {
  proposal: Proposal;
}

const ProposalCard: React.FC<ProposalCardProps> = ({ proposal }) => {
  const navigate = useNavigate();
  const isActive = proposal.endTime > Date.now();
  
  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  };

  return (
    <Card className="overflow-hidden border-blockchain-blue/10 hover:border-blockchain-purple/30 transition-all duration-300">
      <CardHeader className="bg-gradient-to-r from-blockchain-blue to-blockchain-blue/90 text-white">
        <div className="flex justify-between items-center">
          <CardTitle className="text-xl">{proposal.title}</CardTitle>
          {isActive ? (
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 animate-pulse-slow">
              Active
            </span>
          ) : (
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
              Closed
            </span>
          )}
        </div>
        <CardDescription className="text-gray-200">
          Created by {proposal.creator} on {formatDate(proposal.createdAt)}
        </CardDescription>
      </CardHeader>
      <CardContent className="pt-4">
        <p className="text-gray-600 line-clamp-2">{proposal.description}</p>
        <div className="mt-2">
          <p className="text-sm text-gray-500">
            {proposal.choices.length} options • Ends on {formatDate(proposal.endTime)}
          </p>
        </div>
      </CardContent>
      <CardFooter className="border-t border-gray-100 bg-gray-50 py-3">
        <Button 
          onClick={() => navigate(`/proposal/${proposal.id}`)}
          className="bg-blockchain-purple hover:bg-blockchain-purple/90 text-white w-full"
        >
          View Proposal
        </Button>
      </CardFooter>
    </Card>
  );
};

export default ProposalCard;
