
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/contexts/AuthContext";
import { useProposals, Choice } from "@/contexts/ProposalContext";
import { Trash2, Shield } from "lucide-react";
import { toast } from "sonner";

const CreateProposalPage: React.FC = () => {
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuth();
  const { addProposal } = useProposals();
  
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [choices, setChoices] = useState<Choice[]>([
    { id: `choice_${Date.now()}_1`, text: "" },
    { id: `choice_${Date.now()}_2`, text: "" },
  ]);
  const [endDate, setEndDate] = useState("");
  
  // Redirect if not authenticated or not an admin
  React.useEffect(() => {
    if (!isAuthenticated) {
      toast.error("You must be logged in to access this page");
      navigate("/login");
    } else if (user && !user.isAdmin) {
      toast.error("Only administrators can create proposals");
      navigate("/");
    }
  }, [isAuthenticated, navigate, user]);

  const addChoice = () => {
    setChoices([...choices, { id: `choice_${Date.now()}`, text: "" }]);
  };

  const removeChoice = (id: string) => {
    if (choices.length <= 2) {
      toast.error("A proposal must have at least 2 choices");
      return;
    }
    setChoices(choices.filter(choice => choice.id !== id));
  };

  const updateChoice = (id: string, text: string) => {
    setChoices(choices.map(choice => 
      choice.id === id ? { ...choice, text } : choice
    ));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate inputs
    if (!title.trim() || !description.trim() || !endDate) {
      toast.error("Please fill in all required fields");
      return;
    }
    
    // Validate that all choices have text
    const emptyChoices = choices.some(choice => !choice.text.trim());
    if (emptyChoices) {
      toast.error("Please provide text for all choices");
      return;
    }
    
    // Validate end date is in the future
    const endTimestamp = new Date(endDate).getTime();
    if (endTimestamp <= Date.now()) {
      toast.error("End date must be in the future");
      return;
    }
    
    // Create proposal
    addProposal({
      title,
      description,
      choices,
      creator: user?.username || "Unknown",
      endTime: endTimestamp,
    });
    
    toast.success("Proposal created successfully!");
    navigate("/");
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="max-w-2xl mx-auto">
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <CardTitle>Create New Proposal</CardTitle>
              <Shield className="h-5 w-5 text-blockchain-purple" />
            </div>
            <CardDescription>
              Create a new proposal for the community to vote on
            </CardDescription>
          </CardHeader>
          
          <form onSubmit={handleSubmit}>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="title">Proposal Title</Label>
                <Input 
                  id="title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Enter a clear, concise title"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea 
                  id="description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Provide details about your proposal"
                  className="min-h-[120px]"
                  required
                />
              </div>
              
              <div className="space-y-4">
                <Label>Choices</Label>
                {choices.map((choice, index) => (
                  <div key={choice.id} className="flex gap-2">
                    <Input 
                      value={choice.text}
                      onChange={(e) => updateChoice(choice.id, e.target.value)}
                      placeholder={`Choice ${index + 1}`}
                      required
                    />
                    <Button 
                      type="button" 
                      variant="ghost" 
                      size="icon" 
                      className="shrink-0"
                      onClick={() => removeChoice(choice.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
                
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={addChoice}
                  className="mt-2"
                >
                  Add Choice
                </Button>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="end-date">End Date</Label>
                <Input 
                  id="end-date"
                  type="datetime-local"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  required
                />
              </div>
            </CardContent>
            
            <CardFooter className="flex justify-between">
              <Button 
                type="button" 
                variant="outline"
                onClick={() => navigate("/")}
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                className="bg-blockchain-purple hover:bg-blockchain-purple/90"
              >
                Create Proposal
              </Button>
            </CardFooter>
          </form>
        </Card>
      </div>
    </div>
  );
};

export default CreateProposalPage;
