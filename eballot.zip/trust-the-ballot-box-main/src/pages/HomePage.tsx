
import React, { useState } from "react";
import { useProposals, Proposal } from "@/contexts/ProposalContext";
import ProposalCard from "@/components/ProposalCard";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import BlockchainVisualizer from "@/components/BlockchainVisualizer";
import { useDeviceSize } from "@/hooks/use-mobile";
import { useAuth } from "@/contexts/AuthContext";
import ProposalRequestForm from "@/components/ProposalRequestForm";

const HomePage: React.FC = () => {
  const { proposals } = useProposals();
  const [searchTerm, setSearchTerm] = useState("");
  const deviceSize = useDeviceSize();
  const { user, isAuthenticated } = useAuth();
  
  const activeProposals = proposals.filter(p => p.endTime > Date.now());
  const closedProposals = proposals.filter(p => p.endTime <= Date.now());

  const filterProposals = (proposals: Proposal[]) => {
    if (!searchTerm) return proposals;
    
    return proposals.filter(p => 
      p.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.creator.toLowerCase().includes(searchTerm.toLowerCase())
    );
  };

  const filteredActive = filterProposals(activeProposals);
  const filteredClosed = filterProposals(closedProposals);

  // Determine grid columns based on device size
  const gridCols = () => {
    switch (deviceSize) {
      case 'mobile':
        return 'grid-cols-1';
      case 'tablet':
        return 'grid-cols-2';
      default:
        return 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3';
    }
  };

  // Adjust number of blocks in visualizer based on device
  const maxBlocks = deviceSize === 'mobile' ? 3 : deviceSize === 'tablet' ? 4 : 6;

  // Show proposal request form for authenticated non-admin users
  const showRequestForm = isAuthenticated && user && !user.isAdmin;

  return (
    <div className="container mx-auto py-4 sm:py-8 px-4">
      <section className="mb-6 sm:mb-10">
        <div className="text-center mb-6 sm:mb-10">
          <h1 className="text-3xl sm:text-4xl font-bold mb-3 sm:mb-4">
            <span className="text-blockchain-blue">eBallot</span>
          </h1>
          <p className="text-lg sm:text-xl text-gray-600 max-w-2xl mx-auto px-2">
            Secure, transparent voting on the blockchain. Create proposals, cast votes, and view results with complete confidence.
          </p>
        </div>
        
        <BlockchainVisualizer maxBlocks={maxBlocks} />
      </section>

      {/* Proposal Request Form for non-admin users */}
      {showRequestForm && <ProposalRequestForm />}

      <div className="mb-4 sm:mb-6">
        <Input 
          placeholder="Search proposals..." 
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="max-w-md"
        />
      </div>

      <Tabs defaultValue="active" className="mb-6">
        <TabsList className="w-full sm:w-auto">
          <TabsTrigger value="active" className="flex-1 sm:flex-none">Active Proposals ({activeProposals.length})</TabsTrigger>
          <TabsTrigger value="closed" className="flex-1 sm:flex-none">Closed Proposals ({closedProposals.length})</TabsTrigger>
        </TabsList>
        
        <TabsContent value="active" className="pt-4 sm:pt-6">
          {filteredActive.length > 0 ? (
            <div className={`grid ${gridCols()} gap-4 sm:gap-6`}>
              {filteredActive.map(proposal => (
                <ProposalCard key={proposal.id} proposal={proposal} />
              ))}
            </div>
          ) : (
            <div className="text-center py-8 sm:py-12">
              <p className="text-gray-500">
                {searchTerm 
                  ? "No active proposals match your search" 
                  : "No active proposals yet. Create one!"}
              </p>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="closed" className="pt-4 sm:pt-6">
          {filteredClosed.length > 0 ? (
            <div className={`grid ${gridCols()} gap-4 sm:gap-6`}>
              {filteredClosed.map(proposal => (
                <ProposalCard key={proposal.id} proposal={proposal} />
              ))}
            </div>
          ) : (
            <div className="text-center py-8 sm:py-12">
              <p className="text-gray-500">
                {searchTerm 
                  ? "No closed proposals match your search" 
                  : "No closed proposals yet"}
              </p>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default HomePage;
