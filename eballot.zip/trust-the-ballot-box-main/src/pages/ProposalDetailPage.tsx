
import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useProposals } from "@/contexts/ProposalContext";
import { useAuth } from "@/contexts/AuthContext";
import { hasVoted, submitVote, getVotesForProposal } from "@/lib/blockchain";
import BlockchainVisualizer from "@/components/BlockchainVisualizer";
import { Circle, Vote } from "lucide-react";
import { toast } from "sonner";

const ProposalDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { getProposalById } = useProposals();
  const { user, isAuthenticated } = useAuth();
  
  const [selectedChoice, setSelectedChoice] = useState<string>("");
  const [hasUserVoted, setHasUserVoted] = useState<boolean>(false);
  const [votingResults, setVotingResults] = useState<{ [choice: string]: number }>({});
  const [totalVotes, setTotalVotes] = useState<number>(0);
  
  const proposal = id ? getProposalById(id) : undefined;
  const isActive = proposal ? proposal.endTime > Date.now() : false;
  
  useEffect(() => {
    const checkVoteStatus = async () => {
      if (id && user?.id) {
        // Check if the specific user ID has voted on this specific proposal
        console.log("Checking if user", user.id, "has voted on proposal", id);
        const voted = await hasVoted(user.id, id);
        console.log("Vote status for user", user.id, "on proposal", id, ":", voted);
        setHasUserVoted(voted);
      }
    };
    
    checkVoteStatus();
  }, [id, user?.id]);
  
  useEffect(() => {
    const fetchVotingResults = async () => {
      if (id) {
        const results = await getVotesForProposal(id);
        setVotingResults(results);
        
        // Calculate total votes
        const total = Object.values(results).reduce((sum, count) => sum + count, 0);
        setTotalVotes(total);
      }
    };
    
    fetchVotingResults();
  }, [id, hasUserVoted]);
  
  if (!proposal) {
    return (
      <div className="container mx-auto py-16 px-4 text-center">
        <h1 className="text-2xl font-bold mb-4">Proposal Not Found</h1>
        <Button onClick={() => navigate("/")}>Back to Home</Button>
      </div>
    );
  }
  
  const handleVote = async () => {
    if (!isAuthenticated) {
      toast.error("You must be logged in to vote");
      navigate("/login");
      return;
    }
    
    if (!selectedChoice) {
      toast.error("Please select an option");
      return;
    }
    
    if (!isActive) {
      toast.error("This proposal is no longer active");
      return;
    }
    
    // Use the specific voter identity - user ID
    const voterIdentity = user!.id;
    
    // Check again if this specific user has voted on this specific proposal
    if (await hasVoted(voterIdentity, proposal!.id)) {
      toast.error("You have already voted on this proposal");
      return;
    }
    
    // Submit the vote with the specific voter identity and proposal ID
    const success = await submitVote(voterIdentity, proposal!.id, selectedChoice);
    
    if (success) {
      setHasUserVoted(true);
      
      // Update results after successful vote
      const newResults = await getVotesForProposal(proposal!.id);
      setVotingResults(newResults);
      
      const total = Object.values(newResults).reduce((sum, count) => sum + count, 0);
      setTotalVotes(total);
    }
  };
  
  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    });
  };
  
  // Calculate percentage for each choice
  const getPercentage = (choice: string) => {
    if (totalVotes === 0) return 0;
    const votes = votingResults[choice] || 0;
    return Math.round((votes / totalVotes) * 100);
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="max-w-3xl mx-auto">
        <Button 
          variant="ghost" 
          className="mb-6" 
          onClick={() => navigate("/")}
        >
          ← Back to Proposals
        </Button>
        
        <Card className="mb-8 border-blockchain-blue/10 overflow-hidden">
          <CardHeader className="bg-gradient-to-r from-blockchain-blue to-blockchain-blue/90 text-white">
            <div className="flex justify-between items-start">
              <div>
                <CardTitle className="text-2xl">{proposal.title}</CardTitle>
                <CardDescription className="text-gray-200 mt-1">
                  Created by {proposal.creator} on {formatDate(proposal.createdAt)}
                </CardDescription>
              </div>
              
              {isActive ? (
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 animate-pulse-slow">
                  Active until {formatDate(proposal.endTime)}
                </span>
              ) : (
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                  Closed on {formatDate(proposal.endTime)}
                </span>
              )}
            </div>
          </CardHeader>
          
          <CardContent className="py-6">
            <p className="text-gray-700 mb-6 whitespace-pre-line">
              {proposal!.description}
            </p>
            
            {isActive && !hasUserVoted && isAuthenticated ? (
              <div className="mt-6">
                <h3 className="font-medium text-lg mb-4">Cast your vote</h3>
                
                <RadioGroup value={selectedChoice} onValueChange={setSelectedChoice}>
                  {proposal!.choices.map(choice => (
                    <div key={choice.id} className="flex items-center space-x-2 mb-3">
                      <RadioGroupItem value={choice.id} id={choice.id} />
                      <Label htmlFor={choice.id} className="text-base">
                        {choice.text}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
                
                <Button
                  onClick={handleVote} 
                  className="mt-4 bg-blockchain-purple hover:bg-blockchain-purple/90"
                >
                  <Vote className="mr-2 h-4 w-4" />
                  Submit Vote
                </Button>
              </div>
            ) : (
              <>
                {!isAuthenticated && isActive && (
                  <Alert className="mb-6 bg-blockchain-light border-blockchain-purple/30">
                    <AlertDescription className="flex items-center justify-between">
                      <div className="flex items-center">
                        <Circle className="h-4 w-4 mr-2 text-blockchain-purple" />
                        <span>Please login to cast your vote</span>
                      </div>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="border-blockchain-purple text-blockchain-purple"
                        onClick={() => navigate("/login")}
                      >
                        Login
                      </Button>
                    </AlertDescription>
                  </Alert>
                )}
                
                {hasUserVoted && (
                  <Alert className="mb-6 bg-blockchain-light border-blockchain-purple/30">
                    <AlertDescription className="flex items-center">
                      <Circle className="h-4 w-4 mr-2 text-blockchain-purple" />
                      <span>
                        Your vote has been recorded on the blockchain
                      </span>
                    </AlertDescription>
                  </Alert>
                )}
                
                <div className="mt-6">
                  <h3 className="font-medium text-lg mb-4">
                    Results {totalVotes > 0 ? `(${totalVotes} votes)` : '(No votes yet)'}
                  </h3>
                  
                  {proposal!.choices.map(choice => {
                    const percentage = getPercentage(choice.id);
                    const votes = votingResults[choice.id] || 0;
                    
                    return (
                      <div key={choice.id} className="mb-4">
                        <div className="flex justify-between mb-1">
                          <span>{choice.text}</span>
                          <span>{percentage}% ({votes} votes)</span>
                        </div>
                        <Progress value={percentage} className="h-2" />
                      </div>
                    );
                  })}
                </div>
              </>
            )}
          </CardContent>
        </Card>
        
        <BlockchainVisualizer proposal={proposal!.id} maxBlocks={10} />
      </div>
    </div>
  );
};

export default ProposalDetailPage;
