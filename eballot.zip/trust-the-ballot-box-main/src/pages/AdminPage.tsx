
import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useProposals } from "@/contexts/ProposalContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Shield } from "lucide-react";
import { toast } from "sonner";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import BlockchainVisualizer from "@/components/BlockchainVisualizer";
import { format } from "date-fns";
import ProposalRequests from "@/components/ProposalRequests";

const AdminPage: React.FC = () => {
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuth();
  const { proposals } = useProposals();
  
  // Redirect if not authenticated or not an admin
  useEffect(() => {
    if (!isAuthenticated) {
      toast.error("You must be logged in to access this page");
      navigate("/login");
    } else if (user && !user.isAdmin) {
      toast.error("You do not have permission to access this page");
      navigate("/");
    }
  }, [isAuthenticated, navigate, user]);
  
  const handleCreateProposal = () => {
    navigate("/create");
  };
  
  const formatDate = (timestamp: number) => {
    return format(new Date(timestamp), "MMM d, yyyy h:mm a");
  };

  const exportData = () => {
    const dataStr = JSON.stringify({
      proposals: localStorage.getItem("proposals") || "[]",
      votes: localStorage.getItem("votes") || "[]",
      users: JSON.parse(localStorage.getItem("users") || "[]").map((user: any) => ({
        id: user.id,
        username: user.username,
        isAdmin: user.isAdmin
      }))
    }, null, 2);
    
    const dataUri = "data:application/json;charset=utf-8," + encodeURIComponent(dataStr);
    const exportFileDefaultName = "blockchain-data.json";
    
    const linkElement = document.createElement("a");
    linkElement.setAttribute("href", dataUri);
    linkElement.setAttribute("download", exportFileDefaultName);
    linkElement.click();
    
    toast.success("Data exported successfully");
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex items-center gap-2 mb-6">
        <h1 className="text-3xl font-bold">Admin Dashboard</h1>
        <Shield className="h-6 w-6 text-blockchain-purple" />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Total Proposals</CardTitle>
            <CardDescription>Number of proposals created</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-4xl font-bold">{proposals.length}</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Active Proposals</CardTitle>
            <CardDescription>Proposals still open for voting</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-4xl font-bold">{proposals.filter(p => p.endTime > Date.now()).length}</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Completed Proposals</CardTitle>
            <CardDescription>Proposals with voting ended</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-4xl font-bold">{proposals.filter(p => p.endTime <= Date.now()).length}</p>
          </CardContent>
        </Card>
      </div>
      
      <div className="flex justify-between items-center mb-6">
        <Button 
          onClick={handleCreateProposal}
          className="bg-blockchain-purple hover:bg-blockchain-purple/90"
        >
          Create New Proposal
        </Button>
        
        <Button 
          variant="outline"
          onClick={exportData}
        >
          Export Blockchain Data
        </Button>
      </div>
      
      <Tabs defaultValue="proposals" className="mb-6">
        <TabsList>
          <TabsTrigger value="proposals">Manage Proposals</TabsTrigger>
          <TabsTrigger value="requests">Proposal Requests</TabsTrigger>
          <TabsTrigger value="blockchain">Blockchain Status</TabsTrigger>
        </TabsList>
        
        <TabsContent value="proposals" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>All Proposals</CardTitle>
              <CardDescription>Manage all proposals in the system</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Title</TableHead>
                    <TableHead>Creator</TableHead>
                    <TableHead>Created</TableHead>
                    <TableHead>End Date</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {proposals.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center">
                        No proposals found
                      </TableCell>
                    </TableRow>
                  ) : (
                    proposals.map((proposal) => (
                      <TableRow key={proposal.id}>
                        <TableCell className="font-medium">{proposal.title}</TableCell>
                        <TableCell>{proposal.creator}</TableCell>
                        <TableCell>{formatDate(proposal.createdAt)}</TableCell>
                        <TableCell>{formatDate(proposal.endTime)}</TableCell>
                        <TableCell>
                          {proposal.endTime > Date.now() ? (
                            <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs font-semibold">
                              Active
                            </span>
                          ) : (
                            <span className="px-2 py-1 bg-gray-100 text-gray-800 rounded-full text-xs font-semibold">
                              Closed
                            </span>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => navigate(`/proposal/${proposal.id}`)}
                          >
                            View
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="requests" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>User Proposal Requests</CardTitle>
              <CardDescription>Review and manage proposal requests from users</CardDescription>
            </CardHeader>
            <CardContent>
              <ProposalRequests />
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="blockchain" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Blockchain Status</CardTitle>
              <CardDescription>Real-time visualization of the blockchain</CardDescription>
            </CardHeader>
            <CardContent>
              <BlockchainVisualizer maxBlocks={10} />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AdminPage;
