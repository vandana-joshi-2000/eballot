
import React from "react";
import { 
  Card, 
  CardContent, 
  CardHeader
} from "@/components/ui/card";
import { Vote } from "lucide-react";
import OtpHeader from "@/components/otp/OtpHeader";
import OtpForm from "@/components/otp/OtpForm";
import { useOtpVerification } from "@/hooks/useOtpVerification";

const OtpVerificationPage: React.FC = () => {
  const {
    userData,
    otp,
    setOtp,
    isVerifying,
    isSending,
    countdown,
    error,
    handleResendOtp,
    handleVerifyOtp,
    handleGoBack,
    setError
  } = useOtpVerification();

  return (
    <div className="container mx-auto py-8 px-4 md:py-16">
      <div className="max-w-md mx-auto">
        <div className="text-center mb-6">
          <div className="flex justify-center items-center gap-2 mb-4">
            <Vote className="h-8 w-8 text-blockchain-purple" />
            <h1 className="text-2xl font-bold">
              <span className="text-blockchain-blue">eBallot</span>
            </h1>
          </div>
          <p className="text-gray-600">Verify your phone number</p>
        </div>
        
        <Card className="border-blockchain-blue/10">
          <CardHeader>
            <OtpHeader phoneNumber={userData?.phoneNumber} />
          </CardHeader>
          
          <CardContent>
            <OtpForm 
              otp={otp}
              setOtp={(value) => {
                setOtp(value);
                setError(null);
              }}
              error={error}
              isVerifying={isVerifying}
              isSending={isSending}
              countdown={countdown}
              handleResendOtp={handleResendOtp}
              handleVerifyOtp={handleVerifyOtp}
              handleGoBack={handleGoBack}
            />
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default OtpVerificationPage;
